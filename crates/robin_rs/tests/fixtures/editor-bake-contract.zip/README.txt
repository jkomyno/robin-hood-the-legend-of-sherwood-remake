Install this ZIP in the game's configured mods directory and select Bake Contract from Custom Missions. The base game datadir supplies characters and other shared resources.

Reopen editor/editor-bake-contract.rhlos-map.json in the level editor with the referenced pinned asset library. This is the editable scene at export time, including unsaved edits; the ZIP does not duplicate the library models and textures.

This is an unscripted map sandbox. Mission scripts, triggers, and preview population are not exported.
Navigation uses one ground layer. Raised walkways, lifts, jumps, and sloped obstacle heights are not compiled; sight volumes use their full height range.
Scenery without authored obstacles and spline surfaces are visual only. Add obstacle-bearing assets where gameplay collision is required.
